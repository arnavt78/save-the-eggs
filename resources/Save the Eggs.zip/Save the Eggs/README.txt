SAVE THE EGGS
=============

To run the game, simply double-click it. Note that it only works on Windows computers, on an Intel x64 processor. To exit the game, press Alt+F4 while the game window is focused.

Navigate using the WASD or arrow keys. Collect all 32 coins and avoid getting your health too low. Health eventually regenerates randomly.

To win the game, first collect all 32 coins and then touch the blue portal, which teleports you to your nest and makes you win the game!

*Note that the game is unfinished, and when winning or losing, you are simply teleported back to the start and all coins and health are reset.